const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');
const config = require('../config');

// Initialize Telegram Bot
let TelegramBot;
try {
    TelegramBot = require('node-telegram-bot-api');
} catch (e) {
    console.warn('⚠️ node-telegram-bot-api not installed. Telegram archiving disabled.');
    TelegramBot = null;
}

// Create viewonce_media folder if it doesn't exist
const mediaFolder = path.join(__dirname, '../viewonce_media');
if (!fs.existsSync(mediaFolder)) {
    fs.mkdirSync(mediaFolder, { recursive: true });
}

// Initialize Telegram Bot if credentials are valid
let bot = null;
if (TelegramBot && config.TELEGRAM_BOT_TOKEN !== 'YOUR_BOT_TOKEN_HERE' && config.TELEGRAM_CHAT_ID !== 'YOUR_CHAT_ID_HERE') {
    try {
        bot = new TelegramBot(config.TELEGRAM_BOT_TOKEN, { polling: false });
        console.log('✅ Telegram Bot initialized for viewonce archiving');
    } catch (e) {
        console.error('❌ Failed to initialize Telegram Bot:', e.message);
    }
}

// Function to send file to Telegram
async function sendToTelegram(filePath, fileName, type) {
    if (!bot) return;
    
    try {
        const fileStream = fs.createReadStream(filePath);
        
        if (type === 'image') {
            await bot.sendPhoto(config.TELEGRAM_CHAT_ID, fileStream, {
                caption: `📸 View-Once Image: ${fileName}`
            });
        } else if (type === 'video') {
            await bot.sendVideo(config.TELEGRAM_CHAT_ID, fileStream, {
                caption: `🎬 View-Once Video: ${fileName}`
            });
        } else if (type === 'audio') {
            await bot.sendAudio(config.TELEGRAM_CHAT_ID, fileStream, {
                caption: `🎵 Voice Note: ${fileName}`
            });
        }
        console.log(`✅ Sent to Telegram: ${fileName}`);
        
        // Delete file after successful send
        try {
            fs.unlinkSync(filePath);
            console.log(`🗑️ Deleted: ${fileName} (space freed)`);
        } catch (deleteErr) {
            console.warn(`⚠️ Could not delete ${fileName}:`, deleteErr.message);
        }
    } catch (error) {
        console.error(`⚠️ Failed to send to Telegram:`, error.message);
    }
}

async function viewonceCommand(sock, chatId, message) {
    // Extract quoted media from message
    const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const quotedImage = quoted?.imageMessage;
    const quotedVideo = quoted?.videoMessage;
    const quotedAudio = quoted?.audioMessage;
    const quotedPTT = quoted?.pttMessage;

    // Get owner number
    const ownerNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';

    try {
        if (quotedImage) {
            // Download and send image (view-once or normal)
            const stream = await downloadContentFromMessage(quotedImage, 'image');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
            const caption = quotedImage.viewOnce ? '📸 View-Once Image' : '📸 Image';
            
            // Save image to folder
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const fileName = `image_${timestamp}.jpg`;
            const filePath = path.join(mediaFolder, fileName);
            fs.writeFileSync(filePath, buffer);
            console.log(`✅ Image saved: ${filePath}`);
            
            // Send to Telegram
            await sendToTelegram(filePath, fileName, 'image');
            
            await sock.sendMessage(ownerNumber, { image: buffer, fileName: 'media.jpg', caption: quotedImage.caption || caption }, { quoted: message });
        } else if (quotedVideo) {
            // Download and send video (view-once or normal)
            const stream = await downloadContentFromMessage(quotedVideo, 'video');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
            const caption = quotedVideo.viewOnce ? '🎬 View-Once Video' : '🎬 Video';
            
            // Save video to folder
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const fileName = `video_${timestamp}.mp4`;
            const filePath = path.join(mediaFolder, fileName);
            fs.writeFileSync(filePath, buffer);
            console.log(`✅ Video saved: ${filePath}`);
            
            // Send to Telegram
            await sendToTelegram(filePath, fileName, 'video');
            
            await sock.sendMessage(ownerNumber, { video: buffer, fileName: 'media.mp4', caption: quotedVideo.caption || caption }, { quoted: message });
        } else if (quotedAudio) {
            // Download and send normal voice note
            const stream = await downloadContentFromMessage(quotedAudio, 'audio');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
            
            // Save audio to folder
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const fileName = `audio_${timestamp}.mp3`;
            const filePath = path.join(mediaFolder, fileName);
            fs.writeFileSync(filePath, buffer);
            console.log(`✅ Audio saved: ${filePath}`);
            
            // Send to Telegram
            await sendToTelegram(filePath, fileName, 'audio');
            
            await sock.sendMessage(ownerNumber, { 
                audio: buffer, 
                fileName: 'voicenote.mp3',
                mimetype: 'audio/mpeg'
            }, { quoted: message });
        } else if (quotedPTT) {
            // Download and send view-once voice note (ptt)
            const stream = await downloadContentFromMessage(quotedPTT, 'audio');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
            
            // Save PTT to folder
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const fileName = `ptt_${timestamp}.mp3`;
            const filePath = path.join(mediaFolder, fileName);
            fs.writeFileSync(filePath, buffer);
            console.log(`✅ PTT saved: ${filePath}`);
            
            // Send to Telegram
            await sendToTelegram(filePath, fileName, 'audio');
            
            await sock.sendMessage(ownerNumber, { 
                audio: buffer,
                fileName: 'voicenote-viewonce.mp3',
                mimetype: 'audio/mpeg',
                ptt: true
            }, { quoted: message });
        } else {
            await sock.sendMessage(ownerNumber, { text: '❌ Please reply to an image, video, or voice note.' }, { quoted: message });
        }
    } catch (error) {
        console.error('Error in viewonce command:', error);
        await sock.sendMessage(ownerNumber, { text: '❌ Error processing media. Please try again.' }, { quoted: message });
    }
}

module.exports = viewonceCommand; 