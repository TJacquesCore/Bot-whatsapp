const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

async function savestoryCommand(sock, chatId, message) {
    try {
        // Get owner number
        const ownerNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';

        // Extraire le message quoté (le média auquel on répond)
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const quotedImage = quoted?.imageMessage;
        const quotedVideo = quoted?.videoMessage;

        // Vérifier que c'est une réponse à un média
        if (!quotedImage && !quotedVideo) {
            await sock.sendMessage(ownerNumber, { 
                text: '❌ Please reply to an image or video to save as story.' 
            }, { quoted: message });
            return;
        }

        let buffer = Buffer.from([]);
        let mediaType = 'image';

        // Télécharger l'image
        if (quotedImage) {
            const stream = await downloadContentFromMessage(quotedImage, 'image');
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }
            mediaType = 'image';
        }
        // Télécharger la vidéo
        else if (quotedVideo) {
            const stream = await downloadContentFromMessage(quotedVideo, 'video');
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }
            mediaType = 'video';
        }

        // Envoyer le média au owner
        if (mediaType === 'image') {
            await sock.sendMessage(ownerNumber, { 
                image: buffer,
                mimetype: quotedImage?.mimetype || 'image/jpeg',
                fileName: 'media.jpg',
                caption: quotedImage?.caption || 'Saved from story'
            });
        } else if (mediaType === 'video') {
            await sock.sendMessage(ownerNumber, { 
                video: buffer,
                mimetype: quotedVideo?.mimetype || 'video/mp4',
                fileName: 'media.mp4',
                caption: quotedVideo?.caption || 'Saved from story'
            });
        }

        await sock.sendMessage(ownerNumber, { 
            text: '✅ Media saved and sent to you!' 
        }, { quoted: message });

    } catch (error) {
        console.error('Error in savestory command:', error);
        const ownerNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        await sock.sendMessage(ownerNumber, { 
            text: '❌ Error saving media: ' + error.message 
        }, { quoted: message });
    }
}

module.exports = savestoryCommand;
