const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');
const config = require('../config');
const { enqueueSend, simulatePresence, gaussianDelay, wait, delayForMedia } = require('../lib/antiban');

// Telegram toggle controlled by data/telegram.json (disabled by default)
const telegramDataPath = path.join(__dirname, '../data/telegram.json');
let telegramEnabled = false;
try {
    const tgCfg = JSON.parse(fs.readFileSync(telegramDataPath, 'utf8'));
    telegramEnabled = !!tgCfg.enabled;
} catch (e) {
    telegramEnabled = false;
}

// Optional Telegram integration
let TelegramBot;
try {
    TelegramBot = require('node-telegram-bot-api');
} catch (e) {
    TelegramBot = null;
}

let bot = null;
if (telegramEnabled && TelegramBot && config.TELEGRAM_BOT_TOKEN && config.TELEGRAM_CHAT_ID) {
    try {
        bot = new TelegramBot(config.TELEGRAM_BOT_TOKEN, { polling: false });
        console.log('✅ Telegram Bot initialized for viewonce archiving');
    } catch (e) {
        console.error('❌ Failed to initialize Telegram Bot:', e.message);
        bot = null;
    }
}

// Rate limiter for Telegram sends
let telegramTokens = (config.TELEGRAM_TOKENS_PER_MIN || 3);
const TELEGRAM_TOKENS_PER_MIN = telegramTokens;
setInterval(() => { telegramTokens = TELEGRAM_TOKENS_PER_MIN; }, 60 * 1000);

// Folder to store temporary media for Telegram (only used if telegramEnabled)
const mediaFolder = path.join(__dirname, '../viewonce_media');

async function sendToTelegram(filePath, fileName, type, originalCaption) {
    if (!bot || !telegramEnabled) return;
    enqueueSend(async () => {
        if (!bot) return;
        if (telegramTokens <= 0) {
            console.warn('Telegram rate limit reached, re-enqueueing send for', fileName);
            await wait(gaussianDelay(2000, 800, 800, 5000));
            enqueueSend(() => sendToTelegram(filePath, fileName, type, originalCaption), { kind: 'telegram' });
            return;
        }
        telegramTokens -= 1;

        try {
            const fileStream = fs.createReadStream(filePath);
            // jitter before send
            await wait(gaussianDelay(2000, 800, 800, 5000));

            const opts = {};
            if (originalCaption) opts.caption = originalCaption;

            if (type === 'image') {
                await bot.sendPhoto(config.TELEGRAM_CHAT_ID, fileStream, opts);
            } else if (type === 'video') {
                await bot.sendVideo(config.TELEGRAM_CHAT_ID, fileStream, opts);
            } else if (type === 'audio') {
                await bot.sendAudio(config.TELEGRAM_CHAT_ID, fileStream, opts);
            }

            console.log(`✅ Sent to Telegram: ${fileName}`);

            try { fs.unlinkSync(filePath); } catch (deleteErr) { console.warn(`⚠️ Could not delete ${fileName}:`, deleteErr.message); }
        } catch (error) {
            console.error(`⚠️ Failed to send to Telegram:`, error.message);
            await wait(gaussianDelay(3000, 1200, 1000, 8000));
            enqueueSend(() => sendToTelegram(filePath, fileName, type, originalCaption), { kind: 'telegram' });
        }
    }, { kind: 'telegram' });
}

async function viewonceCommand(sock, chatId, message) {
    const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const quotedImage = quoted?.imageMessage;
    const quotedVideo = quoted?.videoMessage;
    const quotedAudio = quoted?.audioMessage;
    const quotedPTT = quoted?.pttMessage;

    const ownerNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';

    try {
        if (quotedImage) {
            const stream = await downloadContentFromMessage(quotedImage, 'image');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
            // Keep original caption only; if none, don't add any caption
            const captionFinal = quotedImage.caption ? quotedImage.caption : undefined;

            // If Telegram archiving enabled, save file and enqueue send
            if (telegramEnabled && bot) {
                try {
                    if (!fs.existsSync(mediaFolder)) fs.mkdirSync(mediaFolder, { recursive: true });
                    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
                    const suffix = Math.random().toString(36).slice(2, 8);
                    const fileName = `image_${timestamp}_${suffix}.jpg`;
                    const filePath = path.join(mediaFolder, fileName);
                    fs.writeFileSync(filePath, buffer);
                    console.log(`✅ Image saved: ${filePath}`);
                    // pass original caption (if any) to Telegram
                    await sendToTelegram(filePath, fileName, 'image', captionFinal);
                } catch (e) {
                    console.warn('Could not save/send image to Telegram:', e.message);
                }
            }

            enqueueSend(async () => {
                await simulatePresence(sock, ownerNumber, 'image');
                await wait(gaussianDelay(1500, 600, 800, 3000));
                const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
                const suffix = Math.random().toString(36).slice(2, 8);
                const outFileName = `image_${timestamp}_${suffix}.jpg`;
                const msg = { image: buffer, fileName: outFileName };
                if (captionFinal) msg.caption = captionFinal;
                await sock.sendMessage(ownerNumber, msg, { quoted: message });
                await wait(delayForMedia('image'));
            });
        } else if (quotedVideo) {
            const stream = await downloadContentFromMessage(quotedVideo, 'video');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
            // Keep original caption only; if none, don't add any caption
            const captionFinal = quotedVideo.caption ? quotedVideo.caption : undefined;

            if (telegramEnabled && bot) {
                try {
                    if (!fs.existsSync(mediaFolder)) fs.mkdirSync(mediaFolder, { recursive: true });
                    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
                    const suffix = Math.random().toString(36).slice(2, 8);
                    const fileName = `video_${timestamp}_${suffix}.mp4`;
                    const filePath = path.join(mediaFolder, fileName);
                    fs.writeFileSync(filePath, buffer);
                    console.log(`✅ Video saved: ${filePath}`);
                    await sendToTelegram(filePath, fileName, 'video', captionFinal);
                } catch (e) {
                    console.warn('Could not save/send video to Telegram:', e.message);
                }
            }

            enqueueSend(async () => {
                await simulatePresence(sock, ownerNumber, 'video');
                await wait(gaussianDelay(2500, 900, 1200, 6000));
                const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
                const suffix = Math.random().toString(36).slice(2, 8);
                const outFileName = `video_${timestamp}_${suffix}.mp4`;
                const msg = { video: buffer, fileName: outFileName };
                if (captionFinal) msg.caption = captionFinal;
                await sock.sendMessage(ownerNumber, msg, { quoted: message });
                await wait(delayForMedia('video'));
            });
        } else if (quotedAudio) {
            const stream = await downloadContentFromMessage(quotedAudio, 'audio');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
            // Keep original caption only; if none, don't add any caption
            const captionFinal = quotedAudio.caption ? quotedAudio.caption : undefined;

            if (telegramEnabled && bot) {
                try {
                    if (!fs.existsSync(mediaFolder)) fs.mkdirSync(mediaFolder, { recursive: true });
                    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
                    const suffix = Math.random().toString(36).slice(2, 8);
                    const fileName = `audio_${timestamp}_${suffix}.mp3`;
                    const filePath = path.join(mediaFolder, fileName);
                    fs.writeFileSync(filePath, buffer);
                    console.log(`✅ Audio saved: ${filePath}`);
                    await sendToTelegram(filePath, fileName, 'audio', captionFinal);
                } catch (e) {
                    console.warn('Could not save/send audio to Telegram:', e.message);
                }
            }

            enqueueSend(async () => {
                await simulatePresence(sock, ownerNumber, 'audio');
                await wait(gaussianDelay(1200, 500, 800, 2500));
                const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
                const suffix = Math.random().toString(36).slice(2, 8);
                const outFileName = `audio_${timestamp}_${suffix}.mp3`;
                await sock.sendMessage(ownerNumber, { 
                    audio: buffer, 
                    fileName: outFileName,
                    mimetype: 'audio/mpeg'
                }, { quoted: message });
                await wait(delayForMedia('audio'));
            });
        } else if (quotedPTT) {
            const stream = await downloadContentFromMessage(quotedPTT, 'audio');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
            // Keep original caption only; if none, don't add any caption
            const captionFinal = quotedPTT.caption ? quotedPTT.caption : undefined;

            if (telegramEnabled && bot) {
                try {
                    if (!fs.existsSync(mediaFolder)) fs.mkdirSync(mediaFolder, { recursive: true });
                    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
                    const suffix = Math.random().toString(36).slice(2, 8);
                    const fileName = `ptt_${timestamp}_${suffix}.mp3`;
                    const filePath = path.join(mediaFolder, fileName);
                    fs.writeFileSync(filePath, buffer);
                    console.log(`✅ PTT saved: ${filePath}`);
                    await sendToTelegram(filePath, fileName, 'audio', captionFinal);
                } catch (e) {
                    console.warn('Could not save/send ptt to Telegram:', e.message);
                }
            }

            enqueueSend(async () => {
                await simulatePresence(sock, ownerNumber, 'ptt');
                await wait(gaussianDelay(1200, 500, 800, 2500));
                const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
                const suffix = Math.random().toString(36).slice(2, 8);
                const outFileName = `ptt_${timestamp}_${suffix}.mp3`;
                await sock.sendMessage(ownerNumber, { 
                    audio: buffer,
                    fileName: outFileName,
                    mimetype: 'audio/mpeg',
                    ptt: true
                }, { quoted: message });
                await wait(delayForMedia('audio'));
            });
        } else {
            enqueueSend(async () => {
                await simulatePresence(sock, ownerNumber, 'text');
                await wait(gaussianDelay(800, 300, 600, 1500));
                await sock.sendMessage(ownerNumber, { text: '❌ Please reply to an image, video, or voice note.' }, { quoted: message });
                await wait(delayForMedia('text'));
            });
        }
    } catch (error) {
        console.error('Error in viewonce command:', error);
        enqueueSend(async () => {
            await simulatePresence(sock, ownerNumber, 'text');
            await wait(gaussianDelay(800, 300, 600, 1500));
            await sock.sendMessage(ownerNumber, { text: '❌ Error processing media. Please try again.' }, { quoted: message });
            await wait(delayForMedia('text'));
        });
    }
}

module.exports = viewonceCommand;