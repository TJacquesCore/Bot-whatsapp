const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

async function viewonceCommand(sock, chatId, message) {
    // Extract quoted media from message
    const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const quotedImage = quoted?.imageMessage;
    const quotedVideo = quoted?.videoMessage;
    const quotedAudio = quoted?.audioMessage;
    const quotedPTT = quoted?.pttMessage;

    // Get owner number
    const ownerNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';

    try {
        if (quotedImage) {
            // Download and send image (view-once or normal)
            const stream = await downloadContentFromMessage(quotedImage, 'image');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
            const caption = quotedImage.viewOnce ? '📸 View-Once Image' : '📸 Image';
            await sock.sendMessage(ownerNumber, { image: buffer, fileName: 'media.jpg', caption: quotedImage.caption || caption }, { quoted: message });
        } else if (quotedVideo) {
            // Download and send video (view-once or normal)
            const stream = await downloadContentFromMessage(quotedVideo, 'video');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
            const caption = quotedVideo.viewOnce ? '🎬 View-Once Video' : '🎬 Video';
            await sock.sendMessage(ownerNumber, { video: buffer, fileName: 'media.mp4', caption: quotedVideo.caption || caption }, { quoted: message });
        } else if (quotedAudio) {
            // Download and send normal voice note
            const stream = await downloadContentFromMessage(quotedAudio, 'audio');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
            await sock.sendMessage(ownerNumber, { 
                audio: buffer, 
                fileName: 'voicenote.mp3',
                mimetype: 'audio/mpeg'
            }, { quoted: message });
        } else if (quotedPTT) {
            // Download and send view-once voice note (ptt)
            const stream = await downloadContentFromMessage(quotedPTT, 'audio');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
            await sock.sendMessage(ownerNumber, { 
                audio: buffer,
                fileName: 'voicenote-viewonce.mp3',
                mimetype: 'audio/mpeg',
                ptt: true
            }, { quoted: message });
        } else {
            await sock.sendMessage(ownerNumber, { text: '❌ Please reply to an image, video, or voice note.' }, { quoted: message });
        }
    } catch (error) {
        console.error('Error in viewonce command:', error);
        await sock.sendMessage(ownerNumber, { text: '❌ Error processing media. Please try again.' }, { quoted: message });
    }
}

module.exports = viewonceCommand; 