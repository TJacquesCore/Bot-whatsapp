const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const { enqueueSend, gaussianDelay, wait, simulatePresence, delayForMedia } = require('../lib/antiban');

async function savestoryCommand(sock, chatId, message) {
    try {
        // Get owner number
        const ownerNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';

        // Extraire le message quoté (le média auquel on répond)
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const quotedImage = quoted?.imageMessage;
        const quotedVideo = quoted?.videoMessage;
        const quotedAudio = quoted?.audioMessage;
        const quotedPTT = quoted?.pttMessage;

        // Vérifier que c'est une réponse à un média
        if (!quotedImage && !quotedVideo && !quotedAudio && !quotedPTT) {
            await wait(gaussianDelay());
            await sock.sendMessage(ownerNumber, { 
                text: '❌ Please reply to an image, video, audio, or voice note to save as story.' 
            }, { quoted: message });
            return;
        }

        let buffer = Buffer.from([]);
        let mediaType = 'image';
        let fileName = 'media';
        let mimetype = 'image/jpeg';

        // Télécharger l'image
        if (quotedImage) {
            const stream = await downloadContentFromMessage(quotedImage, 'image');
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }
            mediaType = 'image';
            fileName = 'story.jpg';
            mimetype = quotedImage?.mimetype || 'image/jpeg';
        }
        // Télécharger la vidéo
        else if (quotedVideo) {
            const stream = await downloadContentFromMessage(quotedVideo, 'video');
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }
            mediaType = 'video';
            fileName = 'story.mp4';
            mimetype = quotedVideo?.mimetype || 'video/mp4';
        }
        // Télécharger l'audio
        else if (quotedAudio) {
            const stream = await downloadContentFromMessage(quotedAudio, 'audio');
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }
            mediaType = 'audio';
            fileName = 'story-audio.mp3';
            mimetype = quotedAudio?.mimetype || 'audio/mpeg';
        }
        // Télécharger la note vocale (PTT)
        else if (quotedPTT) {
            const stream = await downloadContentFromMessage(quotedPTT, 'audio');
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }
            mediaType = 'ptt';
            fileName = 'story-voicenote.mp3';
            mimetype = quotedPTT?.mimetype || 'audio/mpeg';
        }

        // Envoyer le média au owner via la queue (savestory token bucket)
        if (mediaType === 'image') {
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const suffix = Math.random().toString(36).slice(2, 8);
            const outFileName = `story_${timestamp}_${suffix}.jpg`;
            const msg = {
                image: buffer,
                mimetype: mimetype,
                fileName: outFileName
            };
            if (quotedImage?.caption) msg.caption = quotedImage.caption;
            enqueueSend(async () => {
                await wait(gaussianDelay());
                await simulatePresence(sock, ownerNumber, 'image');
                await sock.sendMessage(ownerNumber, msg);
                await wait(delayForMedia('image'));
            }, { kind: 'savestory' });
        } else if (mediaType === 'video') {
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const suffix = Math.random().toString(36).slice(2, 8);
            const outFileName = `story_${timestamp}_${suffix}.mp4`;
            const msg = {
                video: buffer,
                mimetype: mimetype,
                fileName: outFileName
            };
            if (quotedVideo?.caption) msg.caption = quotedVideo.caption;
            enqueueSend(async () => {
                await wait(gaussianDelay());
                await simulatePresence(sock, ownerNumber, 'video');
                await sock.sendMessage(ownerNumber, msg);
                await wait(delayForMedia('video'));
            }, { kind: 'savestory' });
        } else if (mediaType === 'audio') {
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const suffix = Math.random().toString(36).slice(2, 8);
            const outFileName = `story_${timestamp}_${suffix}.mp3`;
            enqueueSend(async () => {
                await wait(gaussianDelay());
                await simulatePresence(sock, ownerNumber, 'audio');
                await sock.sendMessage(ownerNumber, { 
                    audio: buffer,
                    mimetype: mimetype,
                    fileName: outFileName
                });
                await wait(delayForMedia('audio'));
            }, { kind: 'savestory' });
        } else if (mediaType === 'ptt') {
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const suffix = Math.random().toString(36).slice(2, 8);
            const outFileName = `story_${timestamp}_${suffix}.mp3`;
            enqueueSend(async () => {
                await wait(gaussianDelay());
                await simulatePresence(sock, ownerNumber, 'audio');
                await sock.sendMessage(ownerNumber, { 
                    audio: buffer,
                    mimetype: mimetype,
                    fileName: outFileName,
                    ptt: true
                });
                await wait(delayForMedia('audio'));
            }, { kind: 'savestory' });
        }

        // Notification suppressed: no confirmation message after saving story

    } catch (error) {
        console.error('Error in savestory command:', error);
        const ownerNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        await wait(gaussianDelay());
        await sock.sendMessage(ownerNumber, { 
            text: '❌ Error saving media: ' + error.message 
        }, { quoted: message });
    }
}

module.exports = savestoryCommand;
