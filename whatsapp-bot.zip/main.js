const fs = require('fs');
const path = require('path');

// Basic settings and config
const settings = require('./settings');
require('./config.js');
const isOwnerOrSudo = require('./lib/isOwner');

// Keep only the required command handlers
const viewOnceCommand = require('./commands/viewonce');
const savestoryCommand = require('./commands/savestory');
const { handleAntideleteCommand, handleMessageRevocation, storeMessage } = require('./commands/antidelete');

// Minimal channel info used for replies
const channelInfo = {
  contextInfo: {
    forwardingScore: 1,
    isForwarded: true
  }
};

// Placeholder status handler (kept simple)
let handleStatusUpdate = async () => {};

async function handleMessages(sock, messageUpdate) {
  try {
    const { messages, type } = messageUpdate;
    if (type !== 'notify') return;

    const message = messages[0];
    if (!message?.message) return;

    // Store message for antidelete
    if (message.message) storeMessage(sock, message);

    // Handle revocation immediately
    if (message.message?.protocolMessage?.type === 0) {
      await handleMessageRevocation(sock, message);
      return;
    }

    const chatId = message.key.remoteJid;
    const senderId = message.key.participant || message.key.remoteJid;
    const senderIsOwner = await isOwnerOrSudo(senderId, sock, chatId);

    const userMessage = (
      message.message?.conversation?.trim() ||
      message.message?.extendedTextMessage?.text?.trim() ||
      message.message?.imageMessage?.caption?.trim() ||
      message.message?.videoMessage?.caption?.trim() ||
      ''
    ).toLowerCase().trim();

    // Block all command execution for non-owners (silent ignore, no public mode)
    const commandTriggers = ['antidelete', 'savestory', 'cimer'];
    if (commandTriggers.some(t => userMessage.startsWith(t))) {
      if (!message.key.fromMe && !senderIsOwner) return; // silently ignore
    }

    // 'mode' command removed: public mode is disabled permanently.

    // .antidelete
    if (userMessage.startsWith('antidelete')) {
      const antideleteMatch = userMessage.slice('antidelete'.length).trim();
      await handleAntideleteCommand(sock, chatId, message, antideleteMatch);
      return;
    }

    // .savestory
    if (userMessage === 'savestory') {
      await savestoryCommand(sock, chatId, message);
      return;
    }

    // viewonce trigger
    if (userMessage === 'cimer') {
      await viewOnceCommand(sock, chatId, message);
      return;
    }

  } catch (error) {
    console.error('Error in handleMessages:', error);
  }
}

async function handleGroupParticipantUpdate(sock, update) {
  // minimal stub
  return;
}

module.exports = {
  handleMessages,
  handleGroupParticipantUpdate,
  handleStatus: async (sock, status) => {
    await handleStatusUpdate(sock, status);
  }
};
