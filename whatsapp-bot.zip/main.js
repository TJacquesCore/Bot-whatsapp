const fs = require('fs');
const path = require('path');

// Basic settings and config
const settings = require('./settings');
require('./config.js');
const isOwnerOrSudo = require('./lib/isOwner');

// Keep only the required command handlers
const viewOnceCommand = require('./commands/viewonce');
const savestoryCommand = require('./commands/savestory');
const { handleAntideleteCommand, handleMessageRevocation, storeMessage } = require('./commands/antidelete');

// Minimal channel info used for replies
const channelInfo = {
  contextInfo: {
    forwardingScore: 1,
    isForwarded: true
  }
};

// Placeholder status handler (kept simple)
let handleStatusUpdate = async () => {};

async function handleMessages(sock, messageUpdate) {
  try {
    const { messages, type } = messageUpdate;
    if (type !== 'notify') return;

    const message = messages[0];
    if (!message?.message) return;

    // Store message for antidelete
    if (message.message) storeMessage(sock, message);

    // Handle revocation immediately
    if (message.message?.protocolMessage?.type === 0) {
      await handleMessageRevocation(sock, message);
      return;
    }

    const chatId = message.key.remoteJid;
    const senderId = message.key.participant || message.key.remoteJid;
    const senderIsOwner = await isOwnerOrSudo(senderId, sock, chatId);

    const userMessage = (
      message.message?.conversation?.trim() ||
      message.message?.extendedTextMessage?.text?.trim() ||
      message.message?.imageMessage?.caption?.trim() ||
      message.message?.videoMessage?.caption?.trim() ||
      ''
    ).toLowerCase().replace(/\.\s+/g, '.').trim();

    if (!userMessage.startsWith('.')) return;

    // .mode (owner only)
    if (userMessage.startsWith('.mode')) {
      if (!message.key.fromMe && !senderIsOwner) {
        await sock.sendMessage(chatId, { text: 'Only bot owner can use this command!' }, { quoted: message });
        return;
      }
      let data = { isPublic: true };
      try { data = JSON.parse(fs.readFileSync('./data/messageCount.json')) || data; } catch (e) {}
      const action = userMessage.split(' ')[1]?.toLowerCase();
      if (!action) {
        const currentMode = data.isPublic ? 'public' : 'private';
        await sock.sendMessage(chatId, { text: `Current bot mode: *${currentMode}*\n\nUsage: .mode public/private` }, { quoted: message });
        return;
      }
      if (action !== 'public' && action !== 'private') {
        await sock.sendMessage(chatId, { text: 'Usage: .mode public/private' }, { quoted: message });
        return;
      }
      data.isPublic = action === 'public';
      try { fs.writeFileSync('./data/messageCount.json', JSON.stringify(data, null, 2)); } catch (e) {}
      await sock.sendMessage(chatId, { text: `Bot is now in *${action}* mode` }, { quoted: message });
      return;
    }

    // .antidelete
    if (userMessage.startsWith('.antidelete')) {
      const antideleteMatch = userMessage.slice(11).trim();
      await handleAntideleteCommand(sock, chatId, message, antideleteMatch);
      return;
    }

    // .savestory
    if (userMessage === '.savestory') {
      await savestoryCommand(sock, chatId, message);
      return;
    }

    // viewonce trigger
    if (userMessage === '.thanks' || userMessage === '.viewonce') {
      await viewOnceCommand(sock, chatId, message);
      return;
    }

  } catch (error) {
    console.error('Error in handleMessages:', error);
  }
}

async function handleGroupParticipantUpdate(sock, update) {
  // minimal stub
  return;
}

module.exports = {
  handleMessages,
  handleGroupParticipantUpdate,
  handleStatus: async (sock, status) => {
    await handleStatusUpdate(sock, status);
  }
};
